import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Catalog } from '@/components/catalog'
import { getProducts } from '@/lib/actions/products'

export const metadata = {
  title: 'Shop All Products | Ojo Technologies',
  description:
    'Browse smartphones, laptops and accessories at Ojo Technologies. Prices in KSh and USD, pay with M-Pesa.',
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>
}) {
  const { category } = await searchParams
  const products = await getProducts()

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <h1 className="font-heading text-3xl font-bold">Shop</h1>
        <p className="mt-1 text-muted-foreground">
          Genuine electronics with prices in KSh and USD.
        </p>
        <div className="mt-6">
          <Catalog products={products} initialCategory={category ?? 'all'} />
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
