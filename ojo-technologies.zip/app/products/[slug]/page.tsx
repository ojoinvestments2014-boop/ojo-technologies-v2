import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronRight, ShieldCheck, Truck, CheckCircle2 } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Badge } from '@/components/ui/badge'
import { ProductBuyBox } from '@/components/product-buy-box'
import { ProductCard } from '@/components/product-card'
import { formatKes, formatUsd } from '@/lib/currency'
import { getProductBySlug, getRelatedProducts } from '@/lib/actions/products'

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) notFound()

  const related = await getRelatedProducts(product.category, product.id)

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1 text-xs text-muted-foreground">
          <Link href="/products" className="hover:text-primary">
            Shop
          </Link>
          <ChevronRight className="size-3" />
          <Link
            href={`/products?category=${product.category}`}
            className="capitalize hover:text-primary"
          >
            {product.category}
          </Link>
          <ChevronRight className="size-3" />
          <span className="truncate text-foreground">{product.name}</span>
        </nav>

        <div className="mt-6 grid gap-8 md:grid-cols-2">
          <div className="relative aspect-square overflow-hidden rounded-2xl border border-border bg-secondary/30">
            <Image
              src={product.image || '/placeholder.svg'}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-contain p-8"
            />
          </div>

          <div>
            <span className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
              {product.brand}
            </span>
            <h1 className="mt-1 text-balance font-heading text-2xl font-bold sm:text-3xl">
              {product.name}
            </h1>

            <div className="mt-4 flex items-end gap-3">
              <span className="font-heading text-3xl font-extrabold text-primary">
                {formatKes(product.priceKes)}
              </span>
              <span className="pb-1 text-muted-foreground">
                {formatUsd(product.priceUsd)}
              </span>
            </div>

            {product.stock > 0 ? (
              <Badge className="mt-3 gap-1 bg-secondary text-secondary-foreground">
                <CheckCircle2 className="size-3" /> In stock
              </Badge>
            ) : (
              <Badge variant="destructive" className="mt-3">
                Out of stock
              </Badge>
            )}

            <p className="mt-4 leading-relaxed text-muted-foreground">
              {product.description}
            </p>

            <ProductBuyBox product={product} />

            <div className="mt-6 grid gap-3 rounded-xl border border-border bg-card p-4 text-sm">
              <div className="flex items-center gap-2">
                <Truck className="size-4 text-primary" />
                Fast delivery to all 47 counties
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="size-4 text-primary" />
                Genuine product with warranty
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="size-4 text-primary" />
                Pay securely with M-Pesa
              </div>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section className="mt-14">
            <h2 className="font-heading text-xl font-bold">You may also like</h2>
            <div className="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </main>
      <SiteFooter />
    </div>
  )
}
