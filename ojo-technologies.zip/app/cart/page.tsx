import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { CartView } from '@/components/cart-view'

export const metadata = { title: 'Your Cart | Ojo Technologies' }

export default function CartPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <h1 className="font-heading text-3xl font-bold">Your cart</h1>
        <div className="mt-6">
          <CartView />
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
