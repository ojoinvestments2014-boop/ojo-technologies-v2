import Link from 'next/link'
import { CheckCircle2, Package } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Button } from '@/components/ui/button'

export const metadata = { title: 'Order Confirmed | Ojo Technologies' }

export default async function CheckoutSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string; code?: string }>
}) {
  const { order, code } = await searchParams

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center px-4 py-16 text-center">
        <span className="flex size-16 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
          <CheckCircle2 className="size-8" />
        </span>
        <h1 className="mt-6 font-heading text-2xl font-bold">
          Payment received
        </h1>
        <p className="mt-2 text-muted-foreground">
          Thank you for your order! We&apos;ve confirmed your M-Pesa payment and
          your items are being prepared for delivery.
        </p>

        <div className="mt-6 w-full rounded-xl border border-border bg-card p-5 text-left text-sm">
          {order && (
            <div className="flex justify-between py-1">
              <span className="text-muted-foreground">Order number</span>
              <span className="font-semibold">#{order}</span>
            </div>
          )}
          {code && (
            <div className="flex justify-between py-1">
              <span className="text-muted-foreground">M-Pesa code</span>
              <span className="font-mono font-semibold">{code}</span>
            </div>
          )}
        </div>

        <div className="mt-6 flex w-full flex-col gap-2">
          <Button asChild>
            <Link href="/orders">
              <Package className="size-4" /> View my orders
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/products">Continue shopping</Link>
          </Button>
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
