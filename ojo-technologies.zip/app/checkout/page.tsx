import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { CheckoutForm } from '@/components/checkout-form'
import { getSessionUser } from '@/lib/session'

export const metadata = { title: 'Checkout | Ojo Technologies' }

export default async function CheckoutPage() {
  const user = await getSessionUser()

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <h1 className="font-heading text-3xl font-bold">Checkout</h1>
        <div className="mt-6">
          <CheckoutForm userName={user?.name ?? ''} loggedIn={!!user} />
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
